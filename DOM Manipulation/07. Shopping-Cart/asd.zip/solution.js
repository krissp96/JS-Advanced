function solve() {
  //TODO...
  //get add buttons
  const addButtons = document.querySelectorAll(".add-product");

  for (let i = 0; i < addButtons.length; i++) {
    const button = addButtons[i];
    button.addEventListener("click", function (event) {
      const buttonClicked = event.target;
      let productsObj = document.querySelectorAll(".product-title").value;
      console.log(productsObj);
      console.log(buttonClicked);
    });
  }

  //   console.log(object);
  //add products to the cart
  //calculate products prices
  // get the list of products and their total price.toFixed(2)
  //after clicking checkout disable all buttons
  //   const pricesInput = document.querySelectorAll(".product-line-price");

  //   const checkoutButton = document.querySelector(".checkout");
  //   const textArea = document.querySelector("textarea");

  // Attach event listener to checkout button
  //   checkoutButton.addEventListener("click", checkout);
  //   const priceArr = [];
  //   let totalPrice = 0;
  //   //   console.log(totalPrice, "totalPrice");
  //   for (const priceInput of pricesInput) {
  //     //  const productPrice = priceInput.textContent;
  //     priceArr.push(priceInput.textContent);
  //   }
  //   for (const price of priceArr) {
  //     totalPrice += Number(price);
  //   }
  //   //   textArea.value = totalPrice;
  //   console.log(totalPrice);
  //   console.log(priceArr);
  //   //   console.log(pricesInput);
}
